package com.upn.proyectoaplicativos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListaActivity extends AppCompatActivity {
    RecyclerView rvPublicacion;
    FirebaseDatabase database;
    DatabaseReference reference;
    private List<Publicacion>listaPublicacion=new ArrayList<>();

    AdaptadorPersonalizado adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        asignarReferencia();
        inicializarFirebase();
        mostrarDatos();

    }
    private void mostrarDatos(){
        reference.child("Publicacion").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPublicacion.clear();
                for (DataSnapshot item:snapshot.getChildren()){
                    Publicacion p=item.getValue(Publicacion.class);
                    listaPublicacion.add(p);
                }
                adaptador=new AdaptadorPersonalizado(ListaActivity.this,listaPublicacion);
                rvPublicacion.setAdapter(adaptador);
                rvPublicacion.setLayoutManager(new LinearLayoutManager(ListaActivity.this));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void inicializarFirebase(){
        FirebaseApp.initializeApp(this);
        database=FirebaseDatabase.getInstance();
        reference=database.getReference();
    }
    private void asignarReferencia(){
        rvPublicacion=findViewById(R.id.nvPublicacion);
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int pos=viewHolder.getAdapterPosition();
                String id=listaPublicacion.get(pos).getId();
                listaPublicacion.remove(pos);
                adaptador.notifyDataSetChanged();
                reference.child("Publicacion").child(id).removeValue();
            }
        }).attachToRecyclerView(rvPublicacion);
    }
}