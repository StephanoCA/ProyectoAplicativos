package com.upn.proyectoaplicativos;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorPersonalizado extends RecyclerView.Adapter<AdaptadorPersonalizado.MyViewHolder>{
    private Context context;
    private List<Publicacion> listaPublicacion= new ArrayList<>();
    public AdaptadorPersonalizado(Context context,List<Publicacion>listaPublicacion){
        this.context=context;
        this.listaPublicacion=listaPublicacion;
    }
    @NonNull
    @Override
    public AdaptadorPersonalizado.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(this.context);
        View vista=inflater.inflate(R.layout.fila,parent,false);

        return new MyViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorPersonalizado.MyViewHolder holder, int position) {
        holder.filaTitulo.setText(listaPublicacion.get(position).getTitulo()+" ");
        holder.filaDescrip.setText(listaPublicacion.get(position).getDescrip()+"");
        holder.fila.setOnLongClickListener(view -> {
            Intent intent = new Intent(context, RegistrarPublicacionActivity.class);
            intent.putExtra("pid", listaPublicacion.get(position).getId() + "");
            intent.putExtra("ptitulo", listaPublicacion.get(position).getTitulo() + "");
            intent.putExtra("pdescrip", listaPublicacion.get(position).getDescrip() + "");
            context.startActivity(intent);
            return false;
        });

    }

    @Override
    public int getItemCount() {
        return listaPublicacion.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView filaTitulo,filaDescrip;
        LinearLayout fila;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            filaTitulo=itemView.findViewById(R.id.filaTitulo);
            filaDescrip=itemView.findViewById(R.id.filaDesc);
            fila=itemView.findViewById(R.id.fila);
        }
    }
}
