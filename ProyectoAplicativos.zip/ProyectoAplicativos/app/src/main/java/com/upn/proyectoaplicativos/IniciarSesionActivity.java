package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IniciarSesionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion);
    }
}