package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class IniciarSesionActivity extends AppCompatActivity {

    Button btnIng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion);
        asignarReferencia();
    }

    private void asignarReferencia() {
        btnIng = findViewById(R.id.btnIng);
        btnIng.setOnClickListener(v -> {
            Intent intent = new Intent(IniciarSesionActivity.this, NavegarActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
        });
    }
}