package com.upn.proyectoaplicativos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NavegarActivity extends AppCompatActivity {
    menu1 menu_1= new menu1();
   menu2 menu_2= new menu2();
  menu3 menu_3= new menu3();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegar);
        BottomNavigationView  btnNavegar= findViewById(R.id.btnNavegar);
        btnNavegar.setOnNavigationItemSelectedListener(navegacion);
    }
    private final BottomNavigationView.OnNavigationItemSelectedListener navegacion=new BottomNavigationView.OnNavigationItemSelectedListener(){

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_1:
                    loadFragment(menu_1);
                    return true;
                case R.id.menu_2:
                    loadFragment(menu_2);
                    return true;
                case R.id.menu_3:
                    loadFragment(menu_3);
                    return true;

            }
            return false;
        }
    };
    public void loadFragment(Fragment fragment){
        FragmentTransaction transaction= getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container,fragment);
        transaction.commit();
    }
}