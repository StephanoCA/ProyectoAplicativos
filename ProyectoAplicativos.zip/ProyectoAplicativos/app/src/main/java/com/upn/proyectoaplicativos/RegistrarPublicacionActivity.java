package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.UUID;

public class RegistrarPublicacionActivity extends AppCompatActivity {

    EditText txtTitulo, txtDescrip;
    Button btnPublicar;

    Publicacion  publicacion;
    FirebaseDatabase database;
    DatabaseReference reference;
    boolean registra=true;
    String id;
    HashMap map=new HashMap();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_publicacion);
        asignarReferencia();
        inicarFirebase();
        obtenerValores();
    }
    private void obtenerValores(){
        if (getIntent().hasExtra("pid")){
            registra=false;
            id=getIntent().getStringExtra("pid");
            txtTitulo.setText( getIntent().getStringExtra("ptitulo"));
            txtDescrip.setText( getIntent().getStringExtra("pdescrip"));

        }
    }
    private void inicarFirebase(){
        FirebaseApp.initializeApp(this);
        database=FirebaseDatabase.getInstance();
        reference=database.getReference();
    }
    private void asignarReferencia(){
        txtTitulo=findViewById(R.id.txtTitulo);
        txtDescrip=findViewById(R.id.txtDescrip);
        btnPublicar=findViewById(R.id.btnPublicar);
        btnPublicar.setOnClickListener(view -> {
            capturarDatos();
            String mensaje="";

            if (registra) {
                reference.child("Publicacion").child(publicacion.getId()).setValue(publicacion);
                mensaje = "Publicacion agregada";
            }
            else {
                reference.child("Publicacion").child(id).updateChildren(map);
                mensaje="publicaicon actualizada";
            }
            AlertDialog.Builder ventana= new AlertDialog.Builder(RegistrarPublicacionActivity.this);
            ventana.setTitle("mensaje informativo");
            ventana.setMessage(mensaje);
            ventana.setPositiveButton("aceptar",null);
             ventana.create().show();

        });
    }
    private void capturarDatos(){
        String titulo=txtTitulo.getText().toString();
        String descrip=txtDescrip.getText().toString();
        if(registra) {
            publicacion = new Publicacion(UUID.randomUUID().toString(), titulo, descrip);
        }
        else {
            map.put("titulo",titulo);
            map.put("descrip",descrip);
        }
    }
}