package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BottomNavigationMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation_main);
    }
}