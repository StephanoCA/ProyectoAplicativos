package com.upn.proyectoaplicativos;

public class Publicacion {
    private String id;
    private String titulo;
    private String imagen;
    private String descrip;

    public Publicacion() {
    }

    public Publicacion(String id, String titulo, String imagen, String descrip) {
        this.id = id;
        this.titulo = titulo;
        this.imagen = imagen;
        this.descrip = descrip;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }
}
