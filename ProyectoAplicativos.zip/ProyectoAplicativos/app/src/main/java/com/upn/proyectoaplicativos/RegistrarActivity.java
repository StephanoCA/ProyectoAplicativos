package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegistrarActivity extends AppCompatActivity {
    EditText txtNombre,txtApellido,txtChip;
    Button btnGuardar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        casillas();
        guardar();

    }
    private void casillas(){
        txtNombre=findViewById(R.id.txtNombre);
        txtApellido=findViewById(R.id.txtApellido);
        txtChip=findViewById(R.id.txtChip);
        String nom=txtNombre.getText().toString();
        String ape=txtApellido.getText().toString();
        String chip=txtChip.getText().toString();
        if(nom.equals("")){
            txtNombre.setError("Tipo Obligatorio");
        }
        if(ape.equals("")){
            txtApellido.setError("Nombre oligatorio");

        }
        if(chip.equals("")) {
            txtChip.setError("Edad oligatorio");
        }



    }
    private void guardar(){
        btnGuardar=findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(RegistrarActivity.this,BottomNavigationMain.class);
                startActivity(intent);
            }
        });
    }
}