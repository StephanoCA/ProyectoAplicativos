package com.upn.proyectoaplicativos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class IniciarSinChipActivity extends AppCompatActivity {

    Button btnSinC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sin_chip);
        asignarReferencia();
    }

    private void asignarReferencia() {
        btnSinC = findViewById(R.id.btnSinC);
        btnSinC.setOnClickListener(v -> {
            Intent intent = new Intent(IniciarSinChipActivity.this, NavegarActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
        });
    }
}